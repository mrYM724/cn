
import socket
import threading

HOST = "127.0.0.1"
PORT = 12345

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((HOST, PORT))
server.listen()

print(f"Server listening on {HOST}:{PORT}")

clients = []
lock = threading.Lock()

def broadcast(message, sender):
    with lock:
        for client in clients[:]:
            if client is not sender:
                try:
                    client.sendall(message)
                except OSError:
                    clients.remove(client)

def handle(client):
    try:
        while True:
            msg = client.recv(1024)
            if not msg:
                break
            print("Received:", msg.decode())
            broadcast(msg, client)
    except OSError:
        pass
    finally:
        with lock:
            if client in clients:
                clients.remove(client)
        client.close()

while True:
    client, addr = server.accept()
    print("Connected:", addr)
    with lock:
        clients.append(client)
    threading.Thread(target=handle, args=(client,), daemon=True).start()
