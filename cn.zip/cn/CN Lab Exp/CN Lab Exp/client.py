
import socket
import threading

HOST = "127.0.0.1"
PORT = 12345

name = input("Enter your name: ")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

def receive():
    while True:
        try:
            msg = client.recv(1024)
            if not msg:
                break
            print("\n" + msg.decode())
        except OSError:
            break
    print("Disconnected")

threading.Thread(target=receive, daemon=True).start()

try:
    while True:
        message = input()
        client.sendall(f"{name}: {message}".encode())
except (KeyboardInterrupt, EOFError, OSError):
    client.close()
